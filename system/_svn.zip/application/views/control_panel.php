<?php require "header.php" ?>
			<?= $custom_message ?>
<?php require "footer.php" ?>